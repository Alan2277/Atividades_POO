class Empregado {
  String nome = "";
  String cpf = "";

  Empregado({nome, cpf}) {
    this.nome = nome;
    this.cpf = cpf;
  }

  double getSalario() {
    return 0.0;
  }
}
