class Empregado {
  String nome = "";
  String cpf = "";

  Empregado({nome, cpf}) {
    this.nome = nome;
    this.cpf = cpf;
  }
}
